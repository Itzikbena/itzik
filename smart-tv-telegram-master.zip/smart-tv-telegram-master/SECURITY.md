# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| latest commit  | :white_check_mark: |
| any other version   | :x:                |

## Well-known bugs
- we know the files are being transmitted via http, we're highly screwed since the tvs don't support https.
- there is no token to request the files: and after so much they can do mitm (read the point above)
- docker only goes if I use the host network, tell the pychromecast people how to do it without it, and I do it.

## How to contact me
on github somewhere you can click to contact me, but I don't give money anyway so don't bust my balls.
